package com.Deview.Deview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeviewApplication.class, args);
	}

}
